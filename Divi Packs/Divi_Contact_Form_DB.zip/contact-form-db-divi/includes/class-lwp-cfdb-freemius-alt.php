<?php
/**
 * An alternative class to enable premium functionality for ET Marketplace
 * which is disabled by Freemius SDK.
*/
class Lwp_Cfdb_Freemius_Alt {

    public function is__premium_only () {
        return true;
    }

}