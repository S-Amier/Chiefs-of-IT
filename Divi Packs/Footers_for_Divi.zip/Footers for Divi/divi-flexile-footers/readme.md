# Divi Flexile Footers

A footer layout pack for Divi Theme.

## Installation

For other instructions on how to install the layouts, please visit https://diviextended.com/documentation/.

## Support

Please visit https://diviextended.com/support/ for support.

If you made your purchase from the ElegantThemes marketplace, please create a ticket from the support tab of this product on the ElegantThemes marketplace.