<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://elicus.com/
 * @since      1.0.0
 *
 * @package    Divi_Layouts_Extended
 * @subpackage Divi_Layouts_Extended/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Divi_Layouts_Extended
 * @subpackage Divi_Layouts_Extended/includes
 * @author     Elicus <hello@elicus.com>
 */
class Divi_Layouts_Extended_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'divi-layouts-extended',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
