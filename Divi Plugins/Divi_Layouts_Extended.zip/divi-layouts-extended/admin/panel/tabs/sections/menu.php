<?php
global $dle_sections;

if ( empty( $dle_sections ) ) {
    return;
}

$section_types = array_keys( $dle_sections );
asort( $section_types );

?>
<div id="el-settings-panel-sections-wrap" class="el-settings-panel-group">
    <div class="el-settings-panel-sections-wrap">

        <div id="el-settings-panel-sections-all-section" data-type="sections" data-subtype="all" class="form-table el-settings-panel-section el-settings-panel-active-section">
            <div class="el-settings-panel-section-top-bar">
                <h4 class="el-settings-panel-sections-heading">All</h4>
                <?php $this->ajax_filters(); ?>
            </div>
            <?php

                require plugin_dir_path( __FILE__ ) . 'layouts.php';

                echo et_core_intentionally_unescaped(
                    sprintf(
                        '<div class="el-settings-panel-field el-settings-panel-import-list">
                            <div id="%2$s" class="el-settings-panel-import-layout-list">
                                <div class="el-settings-panel-import-layout-gutter"></div>
                                %1$s
                            </div>
                            %3$s
                        </div>',
                        et_core_intentionally_unescaped( $list, 'html' ),
                        et_core_esc_previously( 'el_dle_section_layouts' ),
                        $this->pagination( count( $sections_list ) )
                    ),
                    'html'
                );
                
            ?>
        </div>

        <?php
        foreach( $section_types as $section ) {
            ?>
            <div id="el-settings-panel-sections-<?php echo esc_attr( $section ); ?>-section" data-type="sections" data-subtype="<?php echo esc_attr( $section ); ?>" class="form-table el-settings-panel-section">
                <div class="el-settings-panel-section-top-bar">
                    <h4 class="el-settings-panel-sections-heading"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( '-', ' ', $section ) ) ) ?></h4>
                    <?php $this->ajax_filters(); ?>
                </div>
                <?php

                require plugin_dir_path( __FILE__ ) . 'layouts.php';

                echo et_core_intentionally_unescaped(
                    sprintf(
                        '<div class="el-settings-panel-field el-settings-panel-import-list">
                            <div id="%2$s" class="el-settings-panel-import-layout-list">
                                <div class="el-settings-panel-import-layout-gutter"></div>
                                %1$s
                            </div>
                            %3$s
                        </div>',
                        et_core_intentionally_unescaped( $list, 'html' ),
                        esc_attr( 'el_dle_' . $section . '_layouts' ),
                        $this->pagination( count( $sections_list ) )
                    ),
                    'html'
                );

                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>