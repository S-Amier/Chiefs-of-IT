<?php
global $dle_pages, $preview_icon, $download_icon, $spin_icon, $success_icon;

if ( empty( $dle_pages ) ) {
    return;
}

$pages_list = array();
if ( isset( $page ) ) {
    $pages_list = $dle_pages[$page]['layout'];
} else {
    foreach( $dle_pages as $page ) {
        $pages_list = array_merge( $pages_list, $page['layout'] );
    }
}

$start          = isset( $start ) ? $start : 0;
$sortby         = isset( $sortby ) ? $sortby : 'popular';
$search         = isset( $search ) ? trim( $search ) : '';
$pages_list     = '' !== $search ? $this->get_searched_layouts( $pages_list, $search ) : $pages_list;
if ( ! empty( $pages_list ) ) {
    $pages_list     = $this->get_sorted_layouts( $pages_list, $sortby, $search );
    $layouts        = array_slice( $pages_list, $start, absint( $this->per_page_layouts ) );
    $list           = '';

    foreach( $layouts as $layout ) {

        $image_url = sprintf(
            '%1$s%2$s%3$s%4$s.webp',
            DIVI_LAYOUTS_EXTENDED_THUMBNAILS_PATH,
            isset( $layout['type'] ) ? sanitize_title_with_dashes( $layout['type'] ) . '/' : '',
            isset( $layout['subtype'] ) ? sanitize_title_with_dashes( $layout['subtype'] ) . '/' : '',
            sanitize_title_with_dashes( $layout['title'] )
        );

        $preview_url = sprintf(
            'https://divilayoutsextended.com%1$s%2$s/%3$s',
            isset( $layout['type'] ) && 'post' !== $layout['type'] ? '/' . sanitize_title_with_dashes( $layout['type'] ) : '',
            isset( $layout['subtype'] ) ? '/' . sanitize_title_with_dashes( $layout['subtype'] ) : '',
            sanitize_title_with_dashes( $layout['title'] )
        );

        $list .= sprintf(
            '<div class="el-settings-panel-import-layout el-settings-panel-import-layout-page-%12$s">
                <div class="el-settings-panel-layout-preview">
                    <img src="%1$s" alt="%2$s" />
                </div>
                <div class="el-settings-panel-content-wrapper">
                    <h6 class="el-settings-panel-import-layout-title">%3$s</h6>
                    <div class="el-settings-panel-action-buttons">
                        <a href="javascript:void();" data-url="%4$s" data-text="%5$s" class="el-settings-panel-button el-settings-panel-layout-preview-button">%13$s</a>
                        <a href="javascript:void();" class="el-settings-panel-import-layout-button el-settings-panel-button" data-type="%7$s" data-subtype="%8$s" data-name="%9$s" data-saved_text="%10$s" data-saving_text="%11$s" data-text="%6$s">%14$s %15$s %16$s</a>
                    </div>
                </div>
            </div>',
            esc_url( $image_url ),
            sprintf( esc_html__( '%s Preview', 'divi-layouts-extended' ), ucwords( $layout['title'] ) ),
            sprintf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( $layout['title'] ) ),
            esc_url( $preview_url ),
            esc_html__( 'Preview', 'divi-layouts-extended' ),
            esc_html__( 'Save to Library', 'divi-layouts-extended' ),
            isset( $layout['type'] ) ? sanitize_title_with_dashes( $layout['type'] ) : '',
            isset( $layout['subtype'] ) ? sanitize_title_with_dashes( $layout['subtype'] ) : '',
            sanitize_title_with_dashes( $layout['title'] ),
            esc_attr__( 'Saved', 'divi-layouts-extended' ),
            esc_attr__( 'Saving...', 'divi-layouts-extended' ),
            isset( $paged ) ? $paged : 1,
            et_core_intentionally_unescaped( $preview_icon, 'html' ),
            et_core_intentionally_unescaped( $download_icon, 'html' ),
            et_core_intentionally_unescaped( $spin_icon, 'html' ),
            et_core_intentionally_unescaped( $success_icon, 'html' )
        );
    }
} else {
    $list = '<div class="el-settings-panel-import-layout el-settings-panel-layout-404 el-settings-panel-import-layout-page-1">No Layout found with this keyword. Try searching again...</div>';
}
