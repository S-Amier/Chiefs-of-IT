<?php
global $dle_pages;

if ( empty( $dle_pages ) ) {
    return;
}

$page_types = array_keys( $dle_pages );
asort( $page_types );

?>
<div id="el-settings-panel-pages-wrap" class="el-settings-panel-group">
    <div class="el-settings-panel-sections-wrap">

        <div id="el-settings-panel-pages-all-section" data-type="pages" data-subtype="all" class="form-table el-settings-panel-section el-settings-panel-active-section">
            <div class="el-settings-panel-section-top-bar">
                <h4 class="el-settings-panel-sections-heading">All</h4>
                <?php $this->ajax_filters(); ?>
            </div>
            <?php

            require plugin_dir_path( __FILE__ ) . 'layouts.php';

            echo et_core_intentionally_unescaped(
                sprintf(
                    '<div class="el-settings-panel-field el-settings-panel-import-list">
                        <div id="%2$s" class="el-settings-panel-import-layout-list">
                            <div class="el-settings-panel-import-layout-gutter"></div>
                            %1$s
                        </div>
                        %3$s
                    </div>',
                    et_core_intentionally_unescaped( $list, 'html' ),
                    et_core_esc_previously( 'el_dle_page_layouts' ),
                    $this->pagination( count( $pages_list ) )
                ),
                'html'
            );

            ?>
        </div>
        <?php
        foreach( $page_types as $page ) {
            ?>
            <div id="el-settings-panel-pages-<?php echo esc_attr( str_replace( 'page', '', $page ) ); ?>-section" data-type="pages" data-subtype="<?php echo esc_attr( $page ); ?>" class="form-table el-settings-panel-section">
                <div class="el-settings-panel-section-top-bar">
                    <h4 class="el-settings-panel-sections-heading"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( array( '-', 'page' ), array( ' ', '' ), $page ) ) ) ?></h4>
                    <?php $this->ajax_filters(); ?>
                </div>
                <?php
            
                require plugin_dir_path( __FILE__ ) . 'layouts.php';

                echo et_core_intentionally_unescaped(
                    sprintf(
                        '<div class="el-settings-panel-field el-settings-panel-import-list">
                            <div id="%2$s" class="el-settings-panel-import-layout-list">
                                <div class="el-settings-panel-import-layout-gutter"></div>
                                %1$s
                            </div>
                            %3$s
                        </div>',
                        et_core_intentionally_unescaped( $list, 'html' ),
                        esc_attr( 'el_dle_' . $page . '_layouts' ),
                        $this->pagination( count( $pages_list ) )
                    ),
                    'html'
                );

                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>