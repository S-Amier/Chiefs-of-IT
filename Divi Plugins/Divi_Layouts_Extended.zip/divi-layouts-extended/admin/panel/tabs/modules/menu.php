<?php
global $dle_modules;

if ( empty( $dle_modules ) ) {
    return;
}

$module_types = array_keys( $dle_modules );
asort( $module_types );

?>
<div id="el-settings-panel-modules-wrap" class="el-settings-panel-group">
    <div class="el-settings-panel-sections-wrap">

        <div id="el-settings-panel-modules-all-section" data-type="modules" data-subtype="all" class="form-table el-settings-panel-section el-settings-panel-active-section">
            <div class="el-settings-panel-section-top-bar">
                <h4 class="el-settings-panel-sections-heading">All</h4>
                <?php $this->ajax_filters(); ?>
            </div>
            <?php

            require plugin_dir_path( __FILE__ ) . 'layouts.php';

            echo et_core_intentionally_unescaped(
                sprintf(
                    '<div class="el-settings-panel-field el-settings-panel-import-list">
                        <div id="%2$s" class="el-settings-panel-import-layout-list">
                            <div class="el-settings-panel-import-layout-gutter"></div>
                            %1$s
                        </div>
                        %3$s
                    </div>',
                    et_core_intentionally_unescaped( $list, 'html' ),
                    et_core_esc_previously( 'el_dle_modules_layouts' ),
                    $this->pagination( count( $modules_list ) )
                ),
                'html'
            );

            ?>
        </div>
        <?php
        foreach( $module_types as $module ) {
            ?>
            <div id="el-settings-panel-modules-<?php echo esc_attr( $module ); ?>-section" data-type="modules" data-subtype="<?php echo esc_attr( $module ); ?>" class="form-table el-settings-panel-section">
                <div class="el-settings-panel-section-top-bar">
                    <h4 class="el-settings-panel-sections-heading"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( '-', ' ', $module ) ) ) ?></h4>
                    <?php $this->ajax_filters(); ?>
                </div>
                <?php
                
                require plugin_dir_path( __FILE__ ) . 'layouts.php';

                echo et_core_intentionally_unescaped(
                    sprintf(
                        '<div class="el-settings-panel-field el-settings-panel-import-list">
                            <div id="%2$s" class="el-settings-panel-import-layout-list">
                                <div class="el-settings-panel-import-layout-gutter"></div>
                                %1$s
                            </div>
                            %3$s
                        </div>',
                        et_core_intentionally_unescaped( $list, 'html' ),
                        esc_attr( 'el_dle_' . $module . '_layouts' ),
                        $this->pagination( count( $modules_list ) )
                    ),
                    'html'
                );

                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>