<div id="el-settings-panel-latest-wrap" class="el-settings-panel-group">
    <div class="el-settings-panel-sections-wrap">
        <div id="el-settings-panel-latest-section" data-type="latest" data-subtype="all" class="form-table el-settings-panel-section el-settings-panel-active-section">
            <div class="el-settings-panel-section-top-bar">
                <h4 class="el-settings-panel-sections-heading">Latest</h4>
                <?php $this->ajax_filters('latest'); ?>
            </div>
            <?php

            require plugin_dir_path( __FILE__ ) . 'layouts.php';

            echo et_core_intentionally_unescaped(
                sprintf(
                    '<div class="el-settings-panel-field el-settings-panel-import-list">
                        <div id="%2$s" class="el-settings-panel-import-layout-list">
                            <div class="el-settings-panel-import-layout-gutter"></div>
                            %1$s
                        </div>
                        %3$s
                    </div>',
                    et_core_intentionally_unescaped( $list, 'html' ),
                    et_core_esc_previously( 'el_dle_latest_layouts' ),
                    $this->pagination( count( $all ) )
                ),
                'html'
            );

        ?>
        </div>
    </div>
</div>