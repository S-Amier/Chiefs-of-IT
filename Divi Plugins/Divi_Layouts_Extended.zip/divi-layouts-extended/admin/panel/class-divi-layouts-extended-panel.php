<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://elicus.com/
 * @since      1.0.0
 *
 * @package    Divi_Layouts_Extended
 * @subpackage Divi_Layouts_Extended/admin/panel
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Divi_Layouts_Extended
 * @subpackage Divi_Layouts_Extended/admin/panel
 * @author     Elicus <hello@elicus.com>
 */

if ( ! class_exists( 'Divi_Layouts_Extended_Panel' ) ) {

	class Divi_Layouts_Extended_Panel {

        /**
         * Page title.
         *
         * @var string
         * @access private
         */
        private $page_title;

        /**
         * Layouts
         *
         * @var string
         * @access private
         */
        private $layouts;

        /**
         * Sections Layouts
         *
         * @var string
         * @access private
         */
        private $sections;

        /**
         * Module Layouts
         *
         * @var string
         * @access private
         */
        private $modules;

        /**
         * Pages Layouts
         *
         * @var string
         * @access private
         */
        private $pages;

        /**
         * Per Page Layouts
         *
         * @var string
         * @access private
         */
        private $per_page_layouts = 32;

	    /**
         * Constructs the settings page.
         * 
         * @access public
         */
	    public function __construct( $page_title ) {
            global $dle_sections, $dle_modules, $dle_pages, $preview_icon, $download_icon, $spin_icon, $success_icon;
            $xml = simplexml_load_file( DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/assets/layouts_extended.xml' );

            $preview_icon   = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/preview.svg' );
            $download_icon  = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/download.svg' );
            $spin_icon      = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/spin.svg' );
            $success_icon   = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/success.svg' );

            $this->layouts      = json_decode( json_encode( $xml, true ), true );
            $this->sections     = isset( $this->layouts['sections'] ) ? $this->layouts['sections'] : array();
            $this->modules      = isset( $this->layouts['modules'] ) ? $this->layouts['modules'] : array();
            $this->pages        = isset( $this->layouts['pages'] ) ? $this->layouts['pages'] : array();
            $this->page_title   = $page_title;
            $dle_sections       = $this->sections;
            $dle_modules        = $this->modules;
            $dle_pages          = $this->pages;
        }
        
        /**
         * Creates setting page.
         * 
         * @access public
         * @return void
         */
        public function panel_page() {
            $menu               = ! empty( $this->layouts ) ? array_keys( $this->layouts ) : array();
            $per_page_layouts   = $this->per_page_layouts;
            ?>
            <div class="el-settings-panel-wrapper">
                <div class="el-settings-panel-sidebar">
                    <div class="el-settings-panel-header">
                        <img class="el-settings-panel-logo" src="https://cdn.diviextended.com/divi-layouts-extended/assets/divi-layouts-extended-logo.png">
                    </div>
                    <ul class="el-settings-panel-mainmenu">
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-dashboard-tab el-settings-panel-active-tab">
                            <?php 
                                $dashboard_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/dashboard.svg' );
                                echo et_core_intentionally_unescaped( $dashboard_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-all-wrap"><?php esc_html_e( 'Dashboard', 'divi-layouts-extended' ); ?></span>
                        </li>
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-popular-tab">
                            <?php 
                                $popular_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/popular.svg' );
                                echo et_core_intentionally_unescaped( $popular_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-popular-wrap"><?php esc_html_e( 'Popular', 'divi-layouts-extended' ); ?></span>
                        </li>
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-latest-tab">
                            <?php 
                                $latest_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/latest.svg' );
                                echo et_core_intentionally_unescaped( $latest_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-latest-wrap"><?php esc_html_e( 'Latest', 'divi-layouts-extended' ); ?></span>
                        </li>
                    </ul>
                    <ul class="el-settings-panel-mainmenu">
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-mainmenu-tab-has-children el-settings-panel-sections-tab">
                            <?php 
                                $section_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/sections.svg' );
                                echo et_core_intentionally_unescaped( $section_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-sections-wrap"><?php esc_html_e( 'Sections', 'divi-layouts-extended' ); ?></span>
                            <?php
                                global $dle_sections;
                                if ( ! empty( $dle_sections ) ) {
                                    $section_types = array_keys( $dle_sections );
                                    asort( $section_types );
                                    ?>
                                    <ul class="el-settings-panel-submenu">
                                        <li class="el-settings-panel-submenu-tab">
                                            <span data-href="#el-settings-panel-sections-all-section"><?php esc_html_e( 'All', 'divi-layouts-extended' ); ?></span>
                                        </li>
                                        <?php
                                        foreach( $section_types as $section_type ) {
                                            ?>
                                            <li class="el-settings-panel-submenu-tab">
                                                <span data-href="#el-settings-panel-sections-<?php echo esc_attr( $section_type ); ?>-section"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( '-', ' ', $section_type ) ) ); ?></span>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                    <?php
                                }
                            ?>
                        </li>
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-mainmenu-tab-has-children el-settings-panel-pages-tab">
                            <?php 
                                $pages_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/pages.svg' );
                                echo $pages_icon;
                            ?>
                            <span data-href="#el-settings-panel-pages-wrap"><?php esc_html_e( 'Pages', 'divi-layouts-extended' ); ?></span>
                            <?php
                                global $dle_pages;
                                if ( ! empty( $dle_pages ) ) {
                                    $page_types = array_keys( $dle_pages );
                                    asort( $page_types );
                                    ?>
                                    <ul class="el-settings-panel-submenu">
                                        <li class="el-settings-panel-submenu-tab">
                                            <span data-href="#el-settings-panel-pages-all-section"><?php esc_html_e( 'All', 'divi-layouts-extended' ); ?></span>
                                        </li>
                                        <?php
                                        foreach( $page_types as $page_type ) {
                                            ?>
                                            <li class="el-settings-panel-submenu-tab">
                                                <span data-href="#el-settings-panel-pages-<?php echo esc_attr( str_replace( 'page', '', $page_type ) ); ?>-section"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( array( '-', 'page' ), array( ' ', '' ), $page_type ) ) ); ?></span>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                    <?php
                                }
                            ?>
                        </li>
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-mainmenu-tab-has-children el-settings-panel-modules-tab">
                            <?php 
                                $modules_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/modules.svg' );
                                echo et_core_intentionally_unescaped( $modules_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-modules-wrap"><?php esc_html_e( 'Modules', 'divi-layouts-extended' ); ?></span>
                            <?php
                                global $dle_modules;
                                if ( ! empty( $dle_modules ) ) {
                                    $module_types = array_keys( $dle_modules );
                                    asort( $module_types );
                                    ?>
                                    <ul class="el-settings-panel-submenu">
                                        <li class="el-settings-panel-submenu-tab">
                                            <span data-href="#el-settings-panel-modules-all-section">All</span>
                                        </li>
                                        <?php
                                        foreach( $module_types as $module_type ) {
                                            ?>
                                            <li class="el-settings-panel-submenu-tab">
                                                <span data-href="#el-settings-panel-modules-<?php echo esc_attr( $module_type ); ?>-section"><?php printf( esc_html__( '%s', 'divi-layouts-extended' ), ucwords( str_replace( '-', ' ', $module_type ) ) ); ?></span>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                    <?php
                                }
                            ?>
                        </li>
                    </ul>
                    <ul class="el-settings-panel-mainmenu">
                        <li class="el-settings-panel-mainmenu-tab el-settings-panel-documentation-tab" data-href="https://diviextended.com/documentation/divi-layouts-extended/">
                            <?php 
                                $documentation_icon = file_get_contents( 'https://cdn.diviextended.com/divi-layouts-extended/assets/documentation.svg' );
                                echo et_core_intentionally_unescaped( $documentation_icon, 'html' );
                            ?>
                            <span data-href="#el-settings-panel-documentation-wrap"><?php esc_html_e( 'Documentation', 'divi-layouts-extended' ); ?></span>
                        </li>
                    </ul>
                </div>   
                <div class="el-settings-panel-content">
                    <?php
                        include_once plugin_dir_path( __FILE__ ) .'tabs/all/menu.php';
                        include_once plugin_dir_path( __FILE__ ) .'tabs/popular/menu.php';
                        include_once plugin_dir_path( __FILE__ ) .'tabs/latest/menu.php';
                        if ( ! empty( $menu ) ) {
                            foreach( $menu as $menu_item ) {
                                if ( file_exists( plugin_dir_path( __FILE__ ) .'tabs/' . $menu_item . '/menu.php' ) ) {
                                    include_once plugin_dir_path( __FILE__ ) .'tabs/' . $menu_item . '/menu.php';
                                }
                            }
                        }
                    ?>
                </div>
            </div>
            <?php
        }

        public function get_layouts( $type, $subtype, $search = '', $sortby = 'popular', $paged = 1, $total_pages = 1 ) {

            $type               = sanitize_text_field( $type );
            $subtype            = sanitize_text_field( $subtype );
            $sortby             = sanitize_text_field( $sortby );
            $search             = sanitize_text_field( $search );
            $paged              = absint( $paged );
            $total_pages        = absint( $total_pages );
            $per_page_layouts   = absint( $this->per_page_layouts );
            $list               = '';

            $paged  = max( $paged, 1 );
            $paged  = min( $paged, $total_pages );
            $start  = ( $paged - 1 ) * $per_page_layouts;

            switch ( $type ) {
                case 'sections':
                    if ( 'all' !== $subtype ) {
                        $section = $subtype;
                    }
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/sections/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $sections_list ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                case 'modules':
                    if ( 'all' !== $subtype ) {
                        $module = $subtype;
                    }
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/modules/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $modules_list ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                case 'pages':
                    if ( 'all' !== $subtype ) {
                        $page = $subtype;
                    }
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/pages/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $pages_list ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                case 'all':
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/all/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $all ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                case 'popular':
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/popular/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $all ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                case 'latest':
                    require_once DIVI_LAYOUTS_EXTENDED_ABS_PATH . 'admin/panel/tabs/latest/layouts.php';
                    $data = array(
                        'success' => true,
                        'items' => $list,
                        'total_pages' => max( 1, ceil( count( $all ) / absint( $this->per_page_layouts ) ) ),
                        'current_page' => $paged
                    );
                    return $data;
                    break;

                default:
                    break;
            }
        }

        public function get_sorted_layouts( $layouts, $sortby, $search ) {
            switch ( $sortby ) {
                case 'name-asc':
                    $titles = array_map( 'strtolower', array_column( $layouts, 'title' ) );
                    if ( empty( $search ) ) {
                        array_multisort( preg_replace('/^(\d+)/', '', $titles), SORT_ASC, SORT_NATURAL, $layouts );
                    } else {
                        $pattern        = '/' . $search . '/';
                        $titles_sorted  = preg_replace( $pattern, 'aaaa', $titles );
                        array_multisort( $titles_sorted, SORT_ASC, SORT_NATURAL, preg_replace('/^(\d+)/', '', $titles), SORT_ASC, SORT_NATURAL, $layouts );
                    }
                    break;

                case 'name-desc':
                    $titles = array_map( 'strtolower', array_column( $layouts, 'title' ) );
                    if ( empty( $search ) ) {
                        array_multisort( preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );
                    } else {
                        $pattern        = '/' . $search . '/';
                        $titles_sorted  = preg_replace( $pattern, 'zzzz', $titles );
                        array_multisort( $titles_sorted, SORT_DESC, SORT_NATURAL, preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );
                    }
                    break;

                case 'date-asc':
                    $versions = array_map( 'strtolower', array_column( $layouts, 'version' ) );
                    $titles = array_map( 'strtolower', array_column( $layouts, 'title' ) );
                    if ( empty( $search ) ) {
                        array_multisort( $versions, SORT_ASC, preg_replace('/^(\d+)/', '', $titles), SORT_ASC, SORT_NATURAL, $layouts );
                    } else {
                        $pattern        = '/' . $search . '/';
                        $titles_sorted  = preg_replace( $pattern, 'aaaa', $titles );
                        array_multisort( $versions, SORT_ASC, $titles_sorted, SORT_ASC, SORT_NATURAL, preg_replace('/^(\d+)/', '', $titles), SORT_ASC, SORT_NATURAL, $layouts );
                    }
                    break;

                case 'date-desc':
                    $versions   = array_map( 'strtolower', array_column( $layouts, 'version' ) );
                    $titles     = array_map( 'strtolower', array_column( $layouts, 'title' ) );
                    if ( empty( $search ) ) {
                        array_multisort( $versions, SORT_DESC, preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );
                    } else {
                        $pattern        = '/' . $search . '/';
                        $titles_sorted  = preg_replace( $pattern, 'zzzz', $titles );
                        array_multisort( $versions, SORT_DESC, $titles_sorted, SORT_DESC, SORT_NATURAL, preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );
                    }
                    break;

                case 'popular':
                    $populars   = array_map( 'strtolower', array_column( $layouts, 'popular' ) );
                    $titles     = array_map( 'strtolower', array_column( $layouts, 'title' ) );
                    if ( empty( $search ) ) {
                        $versions   = array_map( 'strtolower', array_column( $layouts, 'version' ) );
                        array_multisort( $populars, SORT_DESC, $versions, SORT_DESC, preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );    
                    } else {
                        $pattern = '/' . $search . '/';
                        $popular_sorted = preg_replace( $pattern, 'zzzz', $titles );
                        array_multisort( $populars, SORT_DESC, $popular_sorted, SORT_DESC, SORT_NATURAL, preg_replace('/^(\d+)/', '', $titles), SORT_DESC, SORT_NATURAL, $layouts );
                    }
                    break;

                default:
                    break;
            }
            return $layouts;
        }

        public function get_searched_layouts( $layouts, $search ) {
            $popular_sorted = array();
            foreach ( $layouts as $key => &$layout ) {
                if ( stripos( $layout['keywords'], $search, 0 ) !== false || stripos( $layout['title'], $search, 0 ) !== false ) {
                    if ( '1' == $layout['popular'] ) {
                        array_push( $popular_sorted, $layouts[$key] );
                        unset($layouts[$key]);
                    }
                } else {
                    unset($layouts[$key]);
                }
            }
            $layouts = array_merge($popular_sorted, $layouts);
            return $layouts;
        }

        public function get_popular_layouts( $layouts ) {
            $popular = array();
            foreach ( $layouts as $key => &$layout ) {
                if ( '1' == $layout['popular'] ) {
                    array_push( $popular, $layouts[$key] );
                }
            }
            return $popular;
        }

        public function get_latest_layouts( $layouts ) {
            $latest = array();
            foreach ( $layouts as $key => &$layout ) {
                if ( DIVI_LAYOUTS_EXTENDED_VERSION == $layout['version'] ) {
                    array_push( $latest, $layouts[$key] );
                }
            }
            return $latest;
        }

        public function pagination( $count = 1 ) {
            $total_pages = ceil( absint( $count ) / absint( $this->per_page_layouts ) );
            $pagination = sprintf(
                '<div class="el-settings-panel-pagination-wrapper" data-total_pages="%1$s" data-per_page_layouts="%2$s"><ul></ul></div>',
                absint( $total_pages ),
                absint( $this->per_page_layouts )
            );
            return et_core_intentionally_unescaped( $pagination, 'html' );
        }

        public function ajax_filters( $type = '' ) {
            ?>
            <div class="el-settings-panel-filter-wrapper">
                <div class="el-settings-panel-search-filter-wrap">
                    <div class="el-settings-panel-search-filter">
                        <!--<span class="el-settings-panel-search-label"><?php echo esc_html__( 'Search for:', 'divi-layouts-extended' ); ?></span>-->
                        <input type="text" name="el_settings_panel_search" class="el-settings-panel-search-field" placeholder="What are you looking for?" />
                    </div>
                </div>
                <div class="el-settings-panel-sort-filter-wrap">
                    <div class="el-settings-panel-sort-filter">
                        <span class="el-settings-panel-sort-label"><?php echo esc_html__( 'Sort by', 'divi-layouts-extended' ); ?></span>
                        <div class="el-settings-panel-sorting-dropdown">
                            <span class="el-settings-panel-dropdown-active-value">
                            <?php 
                            switch( $type ) {
                                case 'popular':
                                    echo esc_html__( 'Date Desc', 'divi-layouts-extended' );
                                    break;

                                case 'latest':
                                    echo esc_html__( 'Popular', 'divi-layouts-extended' );
                                    break;

                                default:
                                    echo esc_html__( 'Popular', 'divi-layouts-extended' );
                                    break;
                            }
                            ?>
                            </span>
                            <span class="el-settings-panel-dropdown-caret"></span>
                            <ul class="el-settings-panel-sorting-dropdown-items">
                                <?php
                                switch( $type ) {
                                    case 'popular':
                                        ?>
                                        <li data-value="name-asc"><?php echo esc_html__( 'Name Asc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="name-desc"><?php echo esc_html__( 'Name Desc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="date-asc"><?php echo esc_html__( 'Date Asc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="date-desc" class="el-settings-panel-dropdown-active-item"><?php echo esc_html__( 'Date Desc', 'divi-layouts-extended' ); ?></li>
                                        <?php
                                        break;

                                    case 'latest':
                                        ?>
                                        <li data-value="name-asc"><?php echo esc_html__( 'Name Asc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="name-desc"><?php echo esc_html__( 'Name Desc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="popular" class="el-settings-panel-dropdown-active-item"><?php echo esc_html__( 'Popular', 'divi-layouts-extended' ); ?></li>
                                        <?php
                                        break;

                                    default:
                                        ?>
                                        <li data-value="name-asc"><?php echo esc_html__( 'Name Asc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="name-desc"><?php echo esc_html__( 'Name Desc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="date-asc"><?php echo esc_html__( 'Date Asc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="date-desc"><?php echo esc_html__( 'Date Desc', 'divi-layouts-extended' ); ?></li>
                                        <li data-value="popular" class="el-settings-panel-dropdown-active-item"><?php echo esc_html__( 'Popular', 'divi-layouts-extended' ); ?></li>
                                        <?php
                                        break;
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }

        public function get_page( $layout_name ) {
            $layout_name = sanitize_title_with_dashes( $layout_name );
            preg_match( '!\d+!', $layout_name, $matches );
            if ( ! empty( $matches ) ) {
                $layout_number = intval( $matches[0] );
                for ($i = 1; $i <= 500; $i+=10) {
                    $min    = $i;
                    $max    = $i+9;
                    $page   = filter_var(
                        $layout_number, 
                        FILTER_VALIDATE_INT, 
                        array(
                            'options' => array(
                                'min_range' => $min, 
                                'max_range' => $max
                            )
                        )
                    );
                    if ( $page && $page === $layout_number ) {
                        if ( $min < 10 ) {
                            $min = '0' . $min;
                        }
                        return '-' . $min . '-' . $max;
                        break;
                    }
                }
            }
            return '';
        }

	    
	}// End of Divi_Layouts_Extended_Panel Class

} // End of class_exists condition