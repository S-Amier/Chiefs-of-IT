<?php
/**
 * Plugin Name:       Divi Layouts Extended
 * Plugin URI:        https://diviextended.com/product/divi-layouts-extended/
 * Description:       A premium plugin for Divi with prebuilt layouts to speed up your web designing process.
 * Version:           2.7.0
 * Author:            Elicus
 * Author URI:        https://elicus.com/
 * Update URI:        https://elegantthemes.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       divi-layouts-extended
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'DIVI_LAYOUTS_EXTENDED_VERSION', '2.7.0' );
define( 'DIVI_LAYOUTS_EXTENDED_PATH', plugin_dir_url( __FILE__ ) );
define( 'DIVI_LAYOUTS_EXTENDED_ABS_PATH', plugin_dir_path( __FILE__ ) );
define( 'DIVI_LAYOUTS_EXTENDED_BASENAME', plugin_basename( __FILE__ ) );
define( 'DIVI_LAYOUTS_EXTENDED_THUMBNAILS_PATH', 'https://cdn.diviextended.com/divi-layouts-extended/thumbnails/' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-divi-layouts-extended.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function divi_layouts_extended() {

	$plugin = new Divi_Layouts_Extended();
	$plugin->run();

}
divi_layouts_extended();